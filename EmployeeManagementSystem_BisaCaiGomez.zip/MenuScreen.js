import React from 'react';
import {SafeAreaView, View, Text, Button} from 'react-native';

import auth from '@react-native-firebase/auth';

import styles from './styles';

const MenuScreen = ({navigation}) => {
  // Set an initializing state whilst Firebase connects
  const [initializing, setInitializing] = React.useState(true);
  const [user, setUser] = React.useState();

  // Handle user state changes
  function onAuthStateChanged(user) {
    setUser(user);
    if (initializing) {
      setInitializing(false);
    }
  }

  React.useEffect(() => {
    const subscriber = auth().onAuthStateChanged(onAuthStateChanged);
    return subscriber; // unsubscribe on unmount
  });

  if (initializing) {
    return null;
  }

  const signOut = () => {
    auth()
      .signOut()
      .then(() => console.log('User signed out!'));
  };

  return (
    <SafeAreaView>
      <View style={{margin: 16}}>
        <Text style={styles.text.title1}>Menu</Text>
        <Button
          title={'Profile'}
          onPress={() => {
            navigation.navigate('Profile');
          }}
        />
        <Button title={'Log Out'} onPress={signOut} />
      </View>
    </SafeAreaView>
  );
};

export default MenuScreen;
