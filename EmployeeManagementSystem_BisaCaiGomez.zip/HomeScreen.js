import React from 'react';
import { Button, SafeAreaView, Text, View } from "react-native";

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import styles from './styles';

const HomeScreen = () => {
  const [user, setUser] = React.useState();

  const getUser = async () => {
    try {
      const doc = await firestore()
        .collection('users')
        .doc(auth().currentUser)
        .get();

      setUser(doc.data());
    } catch {}
  };

  // Get user on mount
  React.useEffect(() => {
    return getUser();
  });

  return (
    <SafeAreaView>
      <View style={{margin: 16}}>
        <Text style={styles.text.title1}>Home</Text>
        <Button
          title={'Time Sheet'}
          onPress={() => {
            navigation.navigate('Time Sheet');
          }}
        />
      </View>
    </SafeAreaView>
  );
};

export default HomeScreen;
