import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Button,
  Platform,
} from 'react-native';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import {Divider} from 'react-native-elements';

import styles from './styles';

const AddEducationScreen = ({navigation}) => {
  const addEducation = (school, degreeProgram, startYear, endYear) => {
    firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('education')
      .add({
        school: school,
        degreeProgram: degreeProgram,
        startYear: startYear,
        endYear: endYear,
      })
      .then(() => {
        console.log('Education added!');
      });
    navigation.navigate('Edit Profile');
  };

  const [school, onChangeSchool] = React.useState();
  const [degreeProgram, onChangeDegreeProgram] = React.useState();
  const [startYear, onChangeStartYear] = React.useState();
  const [endYear, onChangeEndYear] = React.useState();

  return (
    <SafeAreaView>
      <View style={{marginHorizontal: 16}}>
        <Text style={styles.text.title1}>Add Education</Text>
        <View style={{marginVertical: 8}}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>School</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body, {flexShrink: 1}]}
              onChangeText={onChangeSchool}
              value={school}
              placeholder={'School'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>
              Degree Program
            </Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body, {flexShrink: 1}]}
              onChangeText={onChangeDegreeProgram}
              value={degreeProgram}
              placeholder={'Degree Program'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Start Year</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body, {flexShrink: 1}]}
              onChangeText={onChangeStartYear}
              value={startYear}
              placeholder={'Start Year'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>End Year</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body, {flexShrink: 1}]}
              onChangeText={onChangeEndYear}
              value={endYear}
              placeholder={'End Year'}
            />
          </View>
          <Button
            title={'Save'}
            onPress={() =>
              addEducation(school, degreeProgram, startYear, endYear)
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default AddEducationScreen;
