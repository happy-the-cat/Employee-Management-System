import React from 'react';
import {View, Text, TextInput, Button} from 'react-native';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import {useHeaderHeight} from '@react-navigation/stack';

import DateTimePicker from '@react-native-community/datetimepicker';

import styles from './styles';

const CreateUserScreen = ({navigation}) => {
  // Set an initializing state whilst Firebase connects
  const [initializing, setInitializing] = React.useState(true);
  const [user, setUser] = React.useState();

  // Handle user state changes
  function onAuthStateChanged(user) {
    setUser(user);
    if (initializing) {
      setInitializing(false);
    }
  }

  React.useEffect(() => {
    const subscriber = auth().onAuthStateChanged(onAuthStateChanged);
    return subscriber; // unsubscribe on unmount
  });

  const createUser = (
    {email, password},
    {firstName, lastName, title, department},
  ) => {
    auth()
      .createUserWithEmailAndPassword(email, password)
      .then(() => {
        console.log('User account created & signed in!');
        firestore()
          .collection('users')
          .doc(auth().currentUser.uid)
          .set({
            firstName: firstName,
            lastName: lastName,
            title: title,
            department: department,
          })
          .then(() => {
            console.log('User added!');
          });
        navigation.navigate('Sign In');
      })
      .catch(error => {
        if (error.code === 'auth/email-already-in-use') {
          console.log('That email address is already in use!');
        }

        if (error.code === 'auth/invalid-email') {
          console.log('That email address is invalid!');
        }

        console.error(error);
      });
  };

  const headerHeight = useHeaderHeight();

  const [email, onChangeEmail] = React.useState();
  const [password, onChangePassword] = React.useState();

  const [firstName, onChangeFirstName] = React.useState();
  const [lastName, onChangeLastName] = React.useState();

  const [title, onChangeTitle] = React.useState();
  const [department, onChangeDepartment] = React.useState();

  return (
    <View style={{margin: 16, marginTop: headerHeight}}>
      <Text style={styles.text.title1}>Sign Up</Text>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>Email</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          autoFocus={true}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangeEmail}
          value={email}
          placeholder={'Email'}
          keyboardType={'email-address'}
        />
      </View>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>Password</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangePassword}
          value={password}
          placeholder={'Password'}
        />
      </View>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>First Name</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangeFirstName}
          value={firstName}
          placeholder={'First Name'}
        />
      </View>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>Last Name</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangeLastName}
          value={lastName}
          placeholder={'Last Name'}
        />
      </View>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>Title</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangeTitle}
          value={title}
          placeholder={'Title'}
        />
      </View>
      <View
        style={{flexDirection: 'row', marginVertical: 8, alignItems: 'center'}}>
        <Text style={[styles.text.body, {marginRight: 8}]}>Department</Text>
        <TextInput
          autoCapitalize={'none'}
          autoCompleteType={'off'}
          autoCorrect={false}
          style={[styles.text.body, {flexShrink: 1}]}
          onChangeText={onChangeDepartment}
          value={department}
          placeholder={'Department'}
        />
      </View>
      <Button
        title={'Sign Up'}
        onPress={() =>
          createUser(
            {email, password},
            {firstName, lastName, title, department},
          )
        }
      />
    </View>
  );
};

export default CreateUserScreen;
