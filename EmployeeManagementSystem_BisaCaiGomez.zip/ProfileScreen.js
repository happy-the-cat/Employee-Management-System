import React from 'react';
import {
  ActivityIndicator,
  LogBox,
  SafeAreaView,
  ScrollView,
  Text,
  View,
  FlatList,
} from 'react-native';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import {Avatar, Divider} from 'react-native-elements';
import Ionicons from 'react-native-vector-icons/Ionicons';

import Skill from './Skill';
import Education from './Education';
import WorkExperience from './WorkExperience';

import styles from './styles';

const ProfileScreen = ({routes, navigation}) => {
  const [user, setUser] = React.useState();
  const {uid} = auth().currentUser;

  const getUser = async () => {
    try {
      const doc = await firestore().collection('users').doc(uid).get();

      const data = doc.data();
      setUser(data);
    } catch {}
  };

  // Get user on mount
  React.useEffect(() => {
    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);

    return getUser();
  });

  const [loading, setLoading] = React.useState(true); // Set loading to true on component mount
  const [skills, setSkills] = React.useState([]); // Initial empty array of users
  const [education, setEducation] = React.useState([]);
  const [workExperiences, setWorkExperiences] = React.useState([]);

  React.useEffect(() => {
    const subscriber = firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('skills')
      .onSnapshot(querySnapshot => {
        const skills = [];

        querySnapshot.forEach(documentSnapshot => {
          skills.push({
            ...documentSnapshot.data(),
            key: documentSnapshot.id,
          });
        });

        setSkills(skills);
        setLoading(false);
      });

    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);

    // Unsubscribe from events when no longer in use
    return () => subscriber();
  }, []);

  React.useEffect(() => {
    const subscriber = firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('education')
      .onSnapshot(querySnapshot => {
        const education = [];

        querySnapshot.forEach(documentSnapshot => {
          education.push({
            ...documentSnapshot.data(),
            key: documentSnapshot.id,
          });
        });

        setEducation(education);
        setLoading(false);
      });

    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);

    // Unsubscribe from events when no longer in use
    return () => subscriber();
  }, []);

  React.useEffect(() => {
    const subscriber = firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('workExperiences')
      .onSnapshot(querySnapshot => {
        const workExperiences = [];

        querySnapshot.forEach(documentSnapshot => {
          workExperiences.push({
            ...documentSnapshot.data(),
            key: documentSnapshot.id,
          });
        });

        setWorkExperiences(workExperiences);
        setLoading(false);
      });

    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);

    // Unsubscribe from events when no longer in use
    return () => subscriber();
  }, []);

  if (loading) {
    return <ActivityIndicator />;
  }

  return (
    <SafeAreaView>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{margin: 16}}>
          <View style={{alignItems: 'center', marginBottom: 8}}>
            <Avatar
              rounded
              overlayContainerStyle={{backgroundColor: 'green'}}
              size={'large'}
              title={
                user?.firstName.substring(0, 1) +
                user?.lastName.substring(0, 1)
              }
            />
          </View>
          <View style={{alignItems: 'center', marginVertical: 8}}>
            <Text style={styles.text.largeTitle}>
              {user?.firstName} {user?.lastName}
            </Text>
            <Text style={[styles.text.body]}>{user?.title}</Text>
            <Text style={[styles.text.body]}>{user?.department}</Text>
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{marginVertical: 8}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Ionicons
                name={'color-palette-outline'}
                size={24}
                color={'indigo'}
                style={{marginRight: 8}}
              />
              <Text style={styles.text.title3}>Skills</Text>
            </View>
          </View>
          <FlatList
            data={skills}
            renderItem={({item}) => <Skill item={item} />}
          />
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{marginVertical: 8}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Ionicons
                name={'school-outline'}
                size={24}
                color={'indigo'}
                style={{marginRight: 8}}
              />
              <Text style={styles.text.title3}>Education</Text>
            </View>
          </View>
          <FlatList
            data={education}
            renderItem={({item}) => <Education item={item} />}
          />
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{marginVertical: 8}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Ionicons
                name={'briefcase-outline'}
                size={24}
                color={'indigo'}
                style={{marginRight: 8}}
              />
              <Text style={styles.text.title3}>Work Experiences</Text>
            </View>
          </View>
          <FlatList
            data={workExperiences}
            renderItem={({item}) => <WorkExperience item={item} />}
          />
          <View style={{height: 8}} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default ProfileScreen;
