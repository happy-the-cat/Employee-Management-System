import React from 'react';
import {SafeAreaView, View, Text, TextInput, Button} from 'react-native';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import {Divider} from 'react-native-elements';

import Slider from '@react-native-community/slider';

import styles from './styles';

const AddSkillScreen = ({navigation}) => {
  const addSkill = (title, percentage) => {
    firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('skills')
      .add({title: title, percentage: Math.round(percentage)})
      .then(() => {
        console.log('Skill added!');
      });
    navigation.navigate('Edit Profile');
  };

  const [title, onChangeTitle] = React.useState();
  const [percentage, onChangePercentage] = React.useState(0);

  return (
    <SafeAreaView>
      <View style={{marginHorizontal: 16}}>
        <Text style={styles.text.title1}>Add Skill</Text>
        <View style={{marginVertical: 8}}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Title</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body, {flexShrink: 1}]}
              onChangeText={onChangeTitle}
              value={title}
              placeholder={'Title'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Percentage</Text>
            <Slider
              style={{flex: 1}}
              minimumValue={0}
              maximumValue={100}
              minimumTrackTintColor={'green'}
              maximumTrackTintColor="#black"
              onValueChange={onChangePercentage}
              value={percentage}
            />
            <View style={{width: 48, alignItems: 'center'}}>
              <Text style={styles.text.body}>{Math.round(percentage)}%</Text>
            </View>
          </View>
          <Button title={'Save'} onPress={() => addSkill(title, percentage)} />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default AddSkillScreen;
