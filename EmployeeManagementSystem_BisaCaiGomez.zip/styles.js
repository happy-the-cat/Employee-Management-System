import {StyleSheet} from 'react-native';

import Ionicons from 'react-native-vector-icons/Ionicons';
import React from 'react';

const styles = {
  tabScreen: (iconName, tabBarColor) => ({
    tabBarIcon: ({focused, color}) => (
      <Ionicons
        name={focused ? iconName : iconName + '-outline'}
        color={color}
        size={24}
      />
    ),
    tabBarColor: tabBarColor,
  }),
  header: (navigation, iconName, color, navigateName, type) => (
    <Ionicons
      style={type === 0 ? {marginLeft: 16} : {marginRight: 16}}
      name={iconName + '-outline'}
      color={color}
      size={24}
      onPress={() => {
        navigation.navigate(navigateName);
      }}
    />
  ),
  text: StyleSheet.create({
    largeTitle: {
      fontFamily: 'Helvetica',
      fontSize: 34,
      fontWeight: 'bold',
    },
    title1: {
      fontFamily: 'Helvetica',
      fontSize: 28,
      fontWeight: 'bold',
    },
    title2: {
      fontFamily: 'Helvetica',
      fontSize: 22,
      fontWeight: 'bold',
    },
    title3: {
      fontFamily: 'Helvetica',
      fontSize: 20,
      fontWeight: 'bold',
    },
    headline: {
      fontFamily: 'Helvetica',
      fontSize: 17,
    },
    body: {
      fontFamily: 'Helvetica',
      fontSize: 17,
    },
    callout: {
      fontFamily: 'Helvetica',
      fontSize: 16,
    },
    subhead: {
      fontFamily: 'Helvetica',
      fontSize: 15,
    },
    footnote: {
      fontFamily: 'Helvetica',
      fontSize: 13,
    },
    caption1: {
      fontFamily: 'Helvetica',
      fontSize: 12,
    },
    caption2: {
      fontFamily: 'Helvetica',
      fontSize: 11,
    },
  }),
  reanimatedArc: StyleSheet.create({
    container: {
      position: 'relative',
      justifyContent: 'center',
      alignItems: 'center',
      width: 64,
      height: 64,
    },
    absolute: {
      position: 'absolute',
    },
  }),
};

export default styles;
