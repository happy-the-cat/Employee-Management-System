import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

import * as Styles from '../Styles';

const VerticalBarSectionText = ({title, subtitle, barColor}) => {
  return (
    <View style={localStyles.container}>
      <View
        style={[
          localStyles.bar,
          {backgroundColor: barColor ? barColor : Styles.colors.primary},
        ]}
      />
      <View>
        <Text style={Styles.texts.secondary}>{title}</Text>
        <Text style={Styles.texts.secondaryEmphasis}>{subtitle}</Text>
      </View>
    </View>
  );
};

const localStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 4,
  },
  bar: {
    width: 4,
    height: '100%',
    marginRight: 8,
  },
});

export {VerticalBarSectionText};
