export const Users = [
  {
    id: 1,
    email: 'mia.smith@email.com',
    username: 'mia_smith',
    password: 'password',
    userToken: 'token123',
    userType: 'employee',
  },
  {
    id: 2,
    email: 'will.taylor@email.com',
    username: 'will_taylor',
    password: 'password123',
    userToken: 'token12345',
    userType: 'hr',
  },
  {
    id: 3,
    email: 'nancy.osaka@email.com',
    username: 'nancy_osaka',
    password: 'pass1234',
    userToken: 'testtoken',
    userType: 'employee',
  },
];
