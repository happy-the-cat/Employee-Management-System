export const Attendance = [
  '2021-05-08',
  '2021-05-10:2021-05-11',
  '2021-05-13:2021-05-15',
  '2021-05-17:2021-05-20',
  '2021-05-24:2021-05-28',
  '2021-05-31:2021-06-02',
];

// hours worked per day for 2 weeks
export const HoursWorkedEachDay = [8, 8, 8.5];
