import React from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Button,
  Platform,
} from 'react-native';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import {Divider} from 'react-native-elements';

import styles from './styles';

const AddWorkExperienceScreen = ({navigation}) => {
  const addWorkExperience = (title, company, startYear, endYear) => {
    firestore()
      .collection('users')
      .doc(auth().currentUser.uid)
      .collection('workExperiences')
      .add({
        title: title,
        company: company,
        startYear: startYear,
        endYear: endYear,
      })
      .then(() => {
        console.log('Work experience added!');
      });
    navigation.navigate('Edit Profile');
  };

  const [title, onChangeTitle] = React.useState();
  const [company, onChangeCompany] = React.useState();
  const [startYear, onChangeStartYear] = React.useState();
  const [endYear, onChangeEndYear] = React.useState();

  return (
    <SafeAreaView>
      <View style={{marginHorizontal: 16}}>
        <Text style={styles.text.title1}>Add Work Experience</Text>
        <View style={{marginVertical: 8}}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Title</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={styles.text.body}
              onChangeText={onChangeTitle}
              value={title}
              placeholder={'Title'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Company</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={styles.text.body}
              onChangeText={onChangeCompany}
              value={company}
              placeholder={'Company'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Start Year</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={[styles.text.body]}
              onChangeText={onChangeStartYear}
              value={startYear}
              placeholder={'Start Year'}
            />
          </View>
          <Divider style={{marginVertical: 8, backgroundColor: 'dimgray'}} />
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>End Year</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={styles.text.body}
              onChangeText={onChangeEndYear}
              value={endYear}
              placeholder={'End Year'}
            />
          </View>
          <Button
            title={'Save'}
            onPress={() =>
              addWorkExperience(title, company, startYear, endYear)
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default AddWorkExperienceScreen;
