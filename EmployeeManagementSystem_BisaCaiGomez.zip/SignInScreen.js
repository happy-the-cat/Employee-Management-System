import React from 'react';
import {SafeAreaView, View, Text, TextInput, Button} from 'react-native';

import {createMaterialBottomTabNavigator} from '@react-navigation/material-bottom-tabs';
import {createStackNavigator} from '@react-navigation/stack';

import auth from '@react-native-firebase/auth';

import styles from './styles';

import HomeScreen from './HomeScreen';
import OrganizationScreen from './OrganizationScreen';
import ProfileScreen from './ProfileScreen';
import MenuScreen from './MenuScreen';

import EditProfileScreen from './EditProfileScreen';
import AddSkillScreen from './AddSkillScreen';
import AddEducationScreen from './AddEducationScreen';
import AddWorkExperienceScreen from './AddWorkExperienceScreen';

import Ionicons from 'react-native-vector-icons/Ionicons';
import {Menu} from 'react-native-paper';

const Tab = createMaterialBottomTabNavigator();
const Stack = createStackNavigator();

const SignInScreen = ({navigation}) => {
  const [email, onChangeEmail] = React.useState();
  const [password, onChangePassword] = React.useState();

  // Set an initializing state whilst Firebase connects
  const [initializing, setInitializing] = React.useState(true);
  const [user, setUser] = React.useState();

  // Handle user state changes
  function onAuthStateChanged(user) {
    setUser(user);
    if (initializing) {
      setInitializing(false);
    }
  }

  React.useEffect(() => {
    const subscriber = auth().onAuthStateChanged(onAuthStateChanged);
    return subscriber; // unsubscribe on unmount
  });

  if (initializing) {
    return null;
  }

  const signIn = () => {
    auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        console.log('User signed in!');
      })
      .catch(error => {
        if (error.code === 'auth/invalid-email') {
          console.log('That email address is invalid!');
        }

        console.error(error);
      });
  };

  if (!user) {
    return (
      <SafeAreaView>
        <View style={{margin: 16}}>
          <Text style={styles.text.title1}>Log In</Text>
          <View style={{flexDirection: 'row', marginVertical: 8}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Email</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              autoFocus={true}
              style={styles.text.body}
              onChangeText={onChangeEmail}
              value={email}
              placeholder={'Email'}
              keyboardType={'email-address'}
            />
          </View>
          <View style={{flexDirection: 'row', marginVertical: 8}}>
            <Text style={[styles.text.body, {marginRight: 8}]}>Password</Text>
            <TextInput
              autoCapitalize={'none'}
              autoCompleteType={'off'}
              autoCorrect={false}
              style={styles.text.body}
              onChangeText={onChangePassword}
              value={password}
              placeholder={'Password'}
            />
          </View>
          <Button title={'Log In'} onPress={() => signIn()} />
          <Button
            title={'Sign Up'}
            onPress={() => navigation.navigate('Create User')}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <Tab.Navigator initialRouteName={HomeScreen} labeled={false}>
      <Tab.Screen
        name={'Home'}
        component={HomeScreen}
        options={{
          tabBarIcon: ({focused, color}) => (
            <Ionicons
              name={focused ? 'home' : 'home-outline'}
              color={color}
              size={24}
            />
          ),
          tabBarColor: 'darkred',
        }}
      />
      <Tab.Screen
        name={'Organization'}
        component={OrganizationScreen}
        options={{
          tabBarIcon: ({focused, color}) => (
            <Ionicons
              name={focused ? 'business' : 'business-outline'}
              color={color}
              size={24}
            />
          ),
          tabBarColor: 'darkorange',
        }}
      />
      <Tab.Screen
        name={'Profile'}
        component={ProfileScreen}
        options={{
          tabBarIcon: ({focused, color}) => (
            <Ionicons
              name={focused ? 'person' : 'person-outline'}
              color={color}
              size={24}
            />
          ),
          tabBarColor: 'darkgreen',
        }}
      />
      <Tab.Screen
        name={'Menu'}
        component={MyStack}
        options={{
          tabBarIcon: ({focused, color}) => (
            <Ionicons
              name={focused ? 'apps' : 'apps-outline'}
              color={color}
              size={24}
            />
          ),
          tabBarColor: 'indigo',
        }}
      />
    </Tab.Navigator>
  );
};

const MyStack = () => {
  return (
    <Stack.Navigator initialRouteName={'Menu'}>
      <Stack.Screen
        name={'Menu'}
        component={MenuScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name={'Organization'}
        component={OrganizationScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name={'Profile'}
        component={ProfileScreen}
        options={({navigation}) => ({
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerLeft: () =>
            styles.header(navigation, 'arrow-back', 'darkgreen', 'Menu', 0),
          headerBackTitleVisible: false,
          headerTitle: '',
          headerRight: () =>
            styles.header(navigation, 'pencil', 'darkgreen', 'Edit Profile', 1),
        })}
      />
      <Stack.Screen
        name={'Edit Profile'}
        component={EditProfileScreen}
        options={({navigation}) => ({
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerLeft: () =>
            styles.header(navigation, 'arrow-back', 'darkgreen', 'Profile', 0),
          headerBackTitleVisible: false,
          headerTitle: '',
        })}
      />
      <Stack.Screen
        name={'Add Skill'}
        component={AddSkillScreen}
        options={({navigation}) => ({
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerLeft: () =>
            styles.header(navigation, 'close', 'darkgreen', 'Edit Profile', 0),
          headerBackTitleVisible: false,
          headerTitle: '',
        })}
      />
      <Stack.Screen
        name={'Add Education'}
        component={AddEducationScreen}
        options={({navigation}) => ({
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerLeft: () =>
            styles.header(navigation, 'close', 'darkgreen', 'Edit Profile', 0),
          headerBackTitleVisible: false,
          headerTitle: '',
        })}
      />
      <Stack.Screen
        name={'Add Work Experience'}
        component={AddWorkExperienceScreen}
        options={({navigation}) => ({
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerLeft: () =>
            styles.header(navigation, 'close', 'darkgreen', 'Edit Profile', 0),
          headerBackTitleVisible: false,
          headerTitle: '',
        })}
      />
    </Stack.Navigator>
  );
};

export default SignInScreen;
