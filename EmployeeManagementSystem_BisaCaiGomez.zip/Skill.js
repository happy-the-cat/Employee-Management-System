import React from 'react';
import {Text, View} from 'react-native';

import {ProgressBar} from 'react-native-paper';

import styles from './styles';

const Skill = ({item}) => {
  return (
    <View style={{flexDirection: 'row', marginVertical: 4}}>
      <View
        style={{
          width: 4,
          height: '100%',
          backgroundColor: 'green',
          marginRight: 8,
        }}
      />
      <View style={{flex: 1}}>
        <Text
          style={[
            styles.text.body,
            {fontWeight: 'bold', marginRight: 8, marginBottom: 4},
          ]}>
          {item.title}
        </Text>
        <Text style={[styles.text.body, {marginBottom: 4}]}>
          {item.percentage}%
        </Text>
        <ProgressBar
          progress={item.percentage / 100}
          color={'darkgreen'}
          style={{
            height: 8,
            borderRadius: 4,
            backgroundColor: 'lightgrey',
          }}
        />
      </View>
    </View>
  );
};

export default Skill;
