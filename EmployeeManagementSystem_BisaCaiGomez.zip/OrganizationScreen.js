import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  ActivityIndicator,
  FlatList,
  LogBox,
} from 'react-native';

import {Avatar, SearchBar} from 'react-native-elements';

import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

import styles from './styles';
import WorkExperience from './WorkExperience';
import {TouchableItem} from 'react-native-tab-view';

const OrganizationScreen = ({navigation}) => {
  const [loading, setLoading] = React.useState(true); // Set loading to true on component mount
  const [users, setUsers] = React.useState([]); // Initial empty array of users
  const [search, onChangeSearch] = React.useState('');

  React.useEffect(() => {
    const subscriber = firestore()
      .collection('users')
      .onSnapshot(querySnapshot => {
        const users = [];

        querySnapshot.forEach(documentSnapshot => {
          users.push({
            ...documentSnapshot.data(),
            key: documentSnapshot.id,
          });
        });

        setUsers(users);
        setLoading(false);
      });

    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);

    // Unsubscribe from events when no longer in use
    return () => subscriber();
  }, []);

  if (loading) {
    return <ActivityIndicator />;
  }

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={{margin: 16}}>
          <Text style={styles.text.title1}>Organization</Text>
          <SearchBar
            platform={'ios'}
            placeholder={'Search Employee'}
            onChangeText={onChangeSearch}
            value={search}
            containerStyle={{backgroundColor: 'transparent'}}
          />
          <FlatList
            data={users}
            renderItem={({item}) => (
              <TouchableItem>
                <View
                  style={{
                    flexDirection: 'row',
                    marginVertical: 4,
                    alignItems: 'center',
                  }}>
                  <Avatar
                    rounded
                    overlayContainerStyle={{backgroundColor: 'green'}}
                    size={'medium'}
                    title={
                      item?.firstName.toString().substring(0, 1) +
                      item?.lastName.toString().substring(0, 1)
                    }
                    containerStyle={{marginRight: 8}}
                  />
                  <View>
                    <Text style={[styles.text.body, {fontWeight: 'bold'}]}>
                      {item.firstName} {item.lastName}
                    </Text>
                    <Text style={styles.text.footnote}>{item.title}</Text>
                    <Text style={styles.text.footnote}>{item.department}</Text>
                  </View>
                </View>
              </TouchableItem>
            )}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default OrganizationScreen;
