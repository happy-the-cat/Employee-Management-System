import 'react-native-gesture-handler';
import React from 'react';

import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

import SignInScreen from './SignInScreen';
import CreateUserScreen from './CreateUserScreen';

import styles from './styles';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={'Login'}>
        <Stack.Screen
          name={'Sign In'}
          component={SignInScreen}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'Create User'}
          component={CreateUserScreen}
          options={({navigation}) => ({
            headerTransparent: true,
            headerLeft: () =>
              styles.header(
                navigation,
                'arrow-back',
                'darkgreen',
                'Sign In',
                0,
              ),
            headerBackTitleVisible: false,
            headerTitle: '',
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
