import React from 'react';
import {Text, View} from 'react-native';

import styles from './styles';

const WorkExperience = ({item}) => {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 4,
      }}>
      <View
        style={{
          width: 4,
          height: '100%',
          backgroundColor: 'green',
          marginRight: 8,
        }}
      />
      <Text style={styles.text.body}>
        <Text style={{fontWeight: 'bold'}}>
          {item.title}
          {'\n'}
        </Text>
        <Text>
          {item.company}
          {'\n'}
        </Text>
        {item.startYear === item.endYear ? (
          <Text>{item.startYear}</Text>
        ) : item.endYear !== undefined ? (
          <Text>
            {item.startYear}–{item.endYear}
          </Text>
        ) : (
          <Text>{item.startYear}–Present</Text>
        )}
      </Text>
    </View>
  );
};

export default WorkExperience;
